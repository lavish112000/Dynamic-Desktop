import { config } from 'dotenv';
config();

import '@/ai/flows/generate-theme-colors.ts';